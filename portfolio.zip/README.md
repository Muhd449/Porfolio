# Muhd Safwan — Data Analyst Portfolio

A premium, dark-themed, glassmorphism personal portfolio built with plain HTML, CSS and
vanilla JavaScript. No build step, no frameworks — open `index.html` in a browser or
deploy the folder as-is.

## Folder structure

```
/
│── index.html          → all page markup/sections
│── style.css            → all styling (one file, sectioned with comments)
│── script.js             → all interactivity (one file, sectioned with comments)
│── README.md
│── assets/
│     ├── images/
│     │     ├── favicon.svg      ← already included
│     │     ├── profile.jpg      ← add your hero photo here
│     │     ├── about.jpg        ← add your "about" photo here
│     │     ├── project1.jpg … project6.jpg
│     │     └── certificate1.jpg, certificate2.jpg
│     ├── icons/          → (reserved — Font Awesome is loaded via CDN, so this is optional)
│     └── resume.pdf      ← add your actual resume PDF here
```

Until you add real images, every `<img>` tag falls back to a labelled placeholder
graphic automatically (via `onerror`), so the site looks correct even before you add assets.

## 1. Replacing images

Drop files into `assets/images/` using the **exact filenames** already referenced in
`index.html`:
- `profile.jpg` — hero section photo (square, ~500×500px works best)
- `about.jpg` — About section photo (portrait orientation, ~450×520px)
- `project1.jpg` … `project6.jpg` — one per project card (1000×640px / 16:10 ratio)
- `certificate1.jpg`, `certificate2.jpg` — certificate images/scans

If you'd rather use different filenames, just update the matching `src="assets/images/..."`
paths inside `index.html`.

## 2. Replacing the resume

Save your PDF resume as `assets/resume.pdf` (same filename). Both "Download Resume"
buttons already point to that path.

## 3. Updating projects

Each project card lives inside `<section id="projects">` in `index.html`. For every
`.project-card` block, update:
- The image `src`
- `<h3>` title and `<p>` description
- The `.project-tech` tag list
- The two `href="#"` links (point them to your live demo and GitHub repo)
- The `data-category` attribute on the `.project-card` div — this controls the filter
  buttons above the grid (values used: `python`, `sql`, `powerbi`, `excel` — mix and
  match, e.g. `data-category="python sql"`)

## 4. Updating GitHub, LinkedIn and contact info

These appear in **three places** — hero socials, the Contact section, and the footer.
Search `index.html` for these and replace them everywhere they occur:
- `https://github.com/yourusername` → your GitHub profile URL
- `https://linkedin.com/in/Muhd Safwan` → your LinkedIn profile URL (remove the space,
  LinkedIn slugs don't normally contain one)
- `smuhd6820@gmail.com` → your email
- `+91-7818951977` → your phone number
- "Hyderabad, Telangana, India" → your location

## 5. Contact form

The form currently only shows a confirmation message locally (see `script.js`,
section 15 "Contact Form") — it does not send email yet. To make it work for real,
either:
- Use a form backend like **Formspree** or **Web3Forms**: set the `<form>` `action`
  attribute to the endpoint they give you and remove/adjust the JS `preventDefault()`
  handler, or
- Use **EmailJS** (client-side email sending) by adding their SDK script and calling
  `emailjs.send(...)` inside the submit handler, or
- Point it at your own backend API with a `fetch()` POST call.

## 6. Theme, colors & fonts

All design tokens are CSS variables at the top of `style.css` under `:root` —
change `--primary`, `--secondary`, `--accent`, `--bg`, etc. in one place to re-theme
the entire site. The light theme override lives right below it under `[data-theme="light"]`.
Font is Google Fonts **Poppins**, loaded in the `<head>` of `index.html`.

## 7. Deploying

This is a static site — you can drag-and-drop the folder onto Netlify/Vercel, push it
to GitHub Pages, or upload it to any static host. No build step required.
